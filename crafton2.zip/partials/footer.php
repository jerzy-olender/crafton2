<footer>
  <p>&copy; <?php echo date("Y"); ?> Crafton – Wszystkie prawa zastrzeżone</p>
</footer>