<header>
  <div class="container">
    <div class="logo">
    <img src="media/logo.svg" alt="Logo">
  </div>
  <nav>
    <ul>
      <li><a href="#">Strona główna</a></li>
      <li><a href="#">Nasze inwestycje</a></li>
      <li><a href="#">Poradnik</a></li>
      <li><a href="#">Kontakt</a></li>
    </ul>
  </nav>
  </div>
</header>