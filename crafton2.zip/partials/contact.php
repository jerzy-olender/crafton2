<section class="contact">
  <h2>Porozmawiajmy</h2>
  <form action="#" method="post">
    <input type="text" name="name" placeholder="Imię i nazwisko" required>
    <input type="email" name="email" placeholder="Adres e-mail" required>
    <textarea name="message" rows="5" placeholder="Wiadomość"></textarea>
    <button type="submit">Wyślij</button>
  </form>
</section>