<section class="investments" id="investments">
  <h2>Nasze inwestycje</h2>
  <div class="slider">
    <div class="slide">
      <img src="images/real-estate-guide-item-image1.png" alt="Inwestycja 1">
      <h3>Inwestycja 1</h3>
    </div>
    <div class="slide">
      <img src="images/real-estate-guide-item-image2.png" alt="Inwestycja 2">
      <h3>Inwestycja 2</h3>
    </div>
    <div class="slide">
      <img src="images/real-estate-guide-item-image3.png" alt="Inwestycja 3">
      <h3>Inwestycja 3</h3>
    </div>
  </div>
</section>