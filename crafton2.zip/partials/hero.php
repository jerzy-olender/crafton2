<section class="hero">
  <div class="container">
  <h1 class="hero-heading main-heading">Twój klucz do lepszej <br> przyszłości</h1>
  <p class="hero-text main-text">Znajdź najlepsze mieszkania i inwestycje na rynku dzięki naszemu doświadczeniu i wiedzy.</p>
  <a href="#investments" class="main-button-brand">Zobacz inwestycje</a>
  </div>
</section>