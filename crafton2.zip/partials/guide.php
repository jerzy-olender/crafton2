<section class="guide">
  <h2>Poradnik po nieruchomościach</h2>
  <div class="articles">
    <article>
      <img src="media/guide1.jpg" alt="Artykuł 1">
      <h3>Jak wybrać mieszkanie?</h3>
      <a href="#" class="btn">Czytaj więcej</a>
    </article>
    <article>
      <img src="media/guide2.jpg" alt="Artykuł 2">
      <h3>Kupno krok po kroku</h3>
      <a href="#" class="btn">Czytaj więcej</a>
    </article>
    <article>
      <img src="media/guide3.jpg" alt="Artykuł 3">
      <h3>Najczęstsze błędy</h3>
      <a href="#" class="btn">Czytaj więcej</a>
    </article>
  </div>
</section>